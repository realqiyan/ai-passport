import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
workspace = root.parents[1]
voice_source = workspace / 'projects/ai-passport/voice'
voice = root / 'copied source with spaces/voice'
voice.mkdir(parents=True, exist_ok=True)
shutil.copytree(voice_source / 'bridge', voice / 'bridge', dirs_exist_ok=True,
                ignore=shutil.ignore_patterns('.venv', '*.egg-info', '__pycache__'))
for name in ('install.sh', 'start.sh', 'configure.sh', 'uninstall.sh', 'bridge-command.sh'):
    shutil.copy2(voice_source / name, voice / name)
pipx = root / 'tool-env/bin/pipx'
shared_state = root / 'saved state'
for mode in ('editable', 'normal'):
    env = dict(os.environ, PIPX_HOME=str(root/mode/'home'), PIPX_BIN_DIR=str(root/mode/'bin'),
               PIPX_MAN_DIR=str(root/mode/'man'), PASSPORT_VOICE_STATE_DIR=str(shared_state),
               PATH=str(pipx.parent) + os.pathsep + os.environ['PATH'])
    env.pop('PYTHONPATH', None)
    args = [str(pipx), 'install', str(voice / 'bridge')]
    if mode == 'editable':
        args.append('--editable')
    subprocess.run(args, env=env, check=True)
    cli = root/mode/'bin/passport-voice'
    for command in ('usb', 'wifi', 'setup', 'cleanup'):
        subprocess.run([str(cli), command, '--help'], env=env, check=True, stdout=subprocess.DEVNULL)
    venvs = subprocess.check_output([str(pipx), 'environment', '--value', 'PIPX_LOCAL_VENVS'], env=env, text=True).strip()
    python = Path(venvs)/'passport-voice-bridge/bin/python'
    inspection = subprocess.check_output([str(python), '-c',
        'import json; from voice_bridge import cli; print(json.dumps({"token":str(cli.DEFAULT_TOKEN),"package":cli.__file__}))'], env=env, text=True)
    value = json.loads(inspection)
    assert value['token'] == str(shared_state/'token'), value
    subprocess.run([str(python), '-m', 'voice_bridge.cli', 'wifi', '--help'], env=env, check=True, stdout=subprocess.DEVNULL)
    probe = subprocess.run([str(cli), 'usb', '--output', 'BlackHole 2ch'], env=env, text=True, capture_output=True)
    assert probe.returncode == 1 and '/dev/cu.usbmodem' in probe.stderr, probe.stderr
    print(mode, value, flush=True)
    if mode == 'editable':
        forwarded = subprocess.run(['bash', str(voice/'start.sh'), 'wifi', '--shortcut', 'ctrl+shift+v', '--help'], env=env, text=True, capture_output=True)
        assert forwarded.returncode == 0, forwarded.stderr
    subprocess.run([str(pipx), 'uninstall', 'passport-voice-bridge'], env=env, check=True)
print('PASS: editable and normal installs, shared state, module entry, pipx wrapper and uninstall', flush=True)
