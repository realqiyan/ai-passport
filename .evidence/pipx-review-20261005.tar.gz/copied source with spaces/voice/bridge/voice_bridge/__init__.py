"""AI Passport audio bridge."""
